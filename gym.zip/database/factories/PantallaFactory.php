<?php
/**
 * Created by PhpStorm.
 * User: joaquin
 * Date: 07/09/18
 * Time: 16:38
 */
$factory->define(App\Pantalla::class, function (Faker\Generator $faker) {

    return [
        'nombre' => 'admin'


    ];
});
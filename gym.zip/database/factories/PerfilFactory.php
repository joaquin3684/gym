<?php
/**
 * Created by PhpStorm.
 * User: joaquin
 * Date: 07/09/18
 * Time: 16:39
 */
$factory->define(App\Perfil::class, function (Faker\Generator $faker) {

    return [
        'nombre' => 'admin',
    ];
});
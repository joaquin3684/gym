<?php
/**
 * Created by PhpStorm.
 * User: joaquin
 * Date: 22/10/18
 * Time: 18:29
 */

namespace App\services;


use App\Clase;

class ClaseService
{
    public function update($elem, $id)
    {
        $clase = Clase::find($id);
        $clase->fill($elem);
        $clase->save();
    }
}
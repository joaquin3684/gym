<?php
/**
 * Created by PhpStorm.
 * User: joaquin
 * Date: 19/10/18
 * Time: 14:43
 */

namespace App\Enums;


class RegistroEntrada
{
    const ENTRADA_REGISTRADA = 1;
    const ENTRADA_RECHAZADA = 2;
}